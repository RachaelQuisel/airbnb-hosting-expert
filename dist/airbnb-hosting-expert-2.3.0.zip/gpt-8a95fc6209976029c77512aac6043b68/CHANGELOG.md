# Changelog

## 2.3.0 - 2026-11-02

- Update the package version from 0.2.3 to 2.3.0.
- Preserve the hosting instructions, prompts, and icon.

## 0.2.3 - 2026-10-12

- Replace the icon with a Soft Index drawing made using Ghibli Icon Maker's bundled renderer.
- Add the official Airbnb logo as a secondary identifier at the publisher's request.
- Verify 1024 by 1024 RGBA output, thumbnail legibility, and lossless PNG compression.

## 0.2.2 - 2026-10-12

- Replace migrated GPT prose with task-specific hosting instructions and linked reference guides.
- Replace property-specific examples with reusable templates and confirmed-fact requirements.
- Distinguish drafted messages, proposed actions, and verified account changes.
- Add current-source checks, guest-data handling, and independent-assistant disclosure.
- Shorten listing copy to publisher limits and synchronize compatibility metadata.
- Add package documentation and data-handling disclosure.
